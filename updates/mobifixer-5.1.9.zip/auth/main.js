import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";

// Realtime Database import
import { getDatabase, ref, runTransaction }
from "https://www.gstatic.com/firebasejs/12.2.1/firebase-database.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  deleteUser
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";

// One source of truth for the key the app reads on the other side. This module
// is plain arithmetic with no dependencies, so importing it here costs nothing
// and cannot drift from native.js.
import { NOTIFY_ASK_KEY } from "../nativeLogic.js";


const firebaseConfig = {
  apiKey: "AIzaSyAWQP1HENutTN4cPyMM86norOGMSXDnc2g",
  authDomain: "c24o-c038b.firebaseapp.com",
  databaseURL: "https://c24o-c038b-default-rtdb.firebaseio.com",
  projectId: "c24o-c038b",
  storageBucket: "c24o-c038b.firebasestorage.app",
  messagingSenderId: "418015450687",
  appId: "1:418015450687:web:3d0a9632558f242aad4a8a",
  measurementId: "G-X98S86SEV2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

// Reference to your data
//const itemsRef = ref(db, "service");
const shopRef = ref(db, "shops/")

//==========//

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

// Inline messages, replacing 19 alert() popups. Same wording and same logic -
// only the presentation changes. Each page owns its own strip, so a message can
// never surface on the wrong screen, and the markup carries role="status" +
// aria-live so a screen reader still announces it the way a popup interrupted.
const MSG_FOR = {
  '#login-page':  '#login-msg',
  '#reset-page':  '#reset-msg',
  '#signup-page': '#signup-msg'
};

// Some messages are followed straight away by a route change, where an inline
// strip would never be read. Those are parked here and shown by router() on the
// screen the person lands on.
let pendingAuthMessage = null;

const showAuthMessage = (pageSel, text, type = 'error') => {
  const el = $(MSG_FOR[pageSel]);
  if (!el) return;
  el.textContent = text;
  el.classList.remove('is-error', 'is-success', 'is-warn');
  el.classList.add('is-' + type);
  el.classList.remove('hidden');
};

const clearAuthMessages = () => {
  Object.values(MSG_FOR).forEach(sel => {
    const el = $(sel);
    if (!el) return;
    el.textContent = '';
    el.classList.add('hidden');
  });
};

// Disable the submit button and show the overlay together. Without the disable,
// a double tap on Create shop fires two account creations.
const setBusy = (btnSel, busy) => {
  const btn = $(btnSel);
  if (btn) btn.disabled = busy;
  const loader = $('.loader');
  if (loader) loader.classList.toggle('hidden', !busy);
};

let lastHash = location.hash;
let direction = "forward"; // default

window.addEventListener("popstate", () => {
  // back pressed
  direction = "backward";
});

// Carry the business name between the login and reset screens, so nobody has
// to retype it - or mistype it - on the way to a password reset and back. Only
// fills a field that is empty, so it never overwrites what someone just typed.
const carryBusinessName = (fromSel, toSel) => {
  const from = $(fromSel), to = $(toSel);
  if (from && to && from.value.trim() && !to.value.trim()) to.value = from.value.trim();
};

const router = () => {
  const pages = document.querySelectorAll("main");
  pages.forEach(m => m.classList.add('hidden'));

  // A message belongs to the screen it was raised on; leaving it up while the
  // person navigates elsewhere would be worse than the popup it replaced.
  clearAuthMessages();

  let target;
  switch (location.hash) {
    case "#/login":
      target = $("#login-page");
      carryBusinessName('#reset_businessName', '#login_businessName');
      break;
    case "#/signup":
      target = $("#signup-page");
      break;
    case "#/reset":
      target = $("#reset-page");
      carryBusinessName('#login_businessName', '#reset_businessName');
      break;
    default:
      target = $("#home-page");
  }

  // apply animation
  
  target.classList.remove('hidden')

  if (pendingAuthMessage) {
    const { page, text, type } = pendingAuthMessage;
    pendingAuthMessage = null;
    if (target && ('#' + target.id) === page) showAuthMessage(page, text, type);
  }

  lastHash = location.hash;
  direction = "forward"; // reset
};

window.addEventListener("hashchange", router);
router();

$(".get-started-btn").onclick = () => (location.hash = "#/login");

// Show/hide the password. On a phone, typing a password blind into a field you
// cannot check is where most "wrong password" attempts come from.
$$('.pw-toggle').forEach(btn => {
  btn.onclick = () => {
    const input = document.getElementById(btn.dataset.for);
    if (!input) return;
    const reveal = input.type === 'password';
    input.type = reveal ? 'text' : 'password';
    btn.setAttribute('aria-pressed', String(reveal));
    btn.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
  };
});



import { get, child } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-database.js";

// The shop's login email, and nothing else.
//
// This used to read the whole shops/{name} node before signing in. Realtime
// Database evaluates permission at the location you read, so once the security
// rules require auth on shops/$shop that read is denied outright - making
// shops/$shop/owner/email public would not have rescued it, and login would
// have broken for every shop the moment rules went live.
//
// Two paths because the records have two shapes: shops created by signup keep
// the email on owner, and the two created by the old Google sign-in kept it at
// the top level with `owner` as a bare name string. Both are readable
// unauthenticated by design; everything else needs to be signed in.
const lookupShopEmail = async (identifier) => {
  const [onOwner, onShop] = await Promise.all([
    get(child(shopRef, `${identifier}/owner/email`)),
    get(child(shopRef, `${identifier}/email`))
  ]);
  const email = (onOwner.exists() && onOwner.val()) || (onShop.exists() && onShop.val()) || '';
  return String(email).trim();
};

$('#loginForm').onsubmit = async (e) => {
  e.preventDefault();

  const identifier = $('#login_businessName').value.trim().toLowerCase();
  const password = $('#login_businessPass').value.trim();

  if (!identifier || !password) {
    showAuthMessage('#login-page', 'Enter your business name and password.', 'warn');
    return;
  }

  setBusy('#login', true);

  try {
    // The plaintext-password branch that used to sit here is gone. It read a
    // password out of a publicly readable node and, on a first login, called
    // createUserWithEmailAndPassword - a login handler that created accounts.
    // The database export confirms no shop carries a password any more; every
    // one is on Firebase Auth. A shop that somehow still had one goes through
    // Forgot password instead.
    const email = await lookupShopEmail(identifier);

    if (!email) {
      // Either no such shop, or a record with no email on it. Deliberately the
      // same message: a login form should not confirm which shops exist.
      showAuthMessage('#login-page', 'Shop not found, or it has no login email. Check the business name.');
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      localStorage.setItem('shopName', identifier);
      localStorage.setItem('uid', user.uid);
      // Tell the app a sign-in just happened. It asks for notification
      // permission once, after it has the shop's job list - asking here would
      // put an Android dialog in front of a page that is about to navigate
      // away. Signup ends at this screen too, so this covers both routes.
      // Inert on the website: nothing there reads it.
      localStorage.setItem(NOTIFY_ASK_KEY, '1');
      // No message on success: the app opening is the confirmation, and an
      // inline strip would be wiped by the navigation a moment later.
      location = "/";
    } catch (err) {
      if (err.code === "auth/invalid-credential" || err.code === "auth/wrong-password" ||
          err.code === "auth/user-not-found") {
        // Dead end before this: a reset email is now the only way back in, so
        // say so rather than leaving someone guessing at the same field.
        showAuthMessage('#login-page', 'Wrong password. If you don\u2019t remember it, tap "Forgot password?" to get a reset link by email.');
      } else if (err.code === "auth/too-many-requests") {
        showAuthMessage('#login-page', 'Too many attempts. Please wait a few minutes and try again.', 'warn');
      } else {
        console.error(err);
        showAuthMessage('#login-page', 'Login failed: ' + err.message);
      }
    }
  } catch (err) {
    console.error(err);
    showAuthMessage('#login-page', 'Something went wrong: ' + err.message);
  } finally {
    setBusy('#login', false);
  }
};


// 🔐 Forgot password → send Firebase reset email to the shop's registered email
$('#resetForm').onsubmit = async (e) => {
  e.preventDefault();

  const identifier = $('#reset_businessName').value.trim().toLowerCase();

  if (!identifier) {
    showAuthMessage('#reset-page', 'Enter your business name.', 'warn');
    return;
  }

  setBusy('#reset-btn', true);

  try {
    // Same narrow lookup as login: only the public email paths, never the whole
    // shop node, so this keeps working once the security rules are applied.
    const email = await lookupShopEmail(identifier);

    if (!email) {
      showAuthMessage('#reset-page', 'Shop not found, or no email is registered for it. Check the business name, or contact support.');
      return;
    }

    // The checks that used to sit here - "does this shop have a Firebase Auth
    // account yet" and "is it still on a plaintext password" - are gone with
    // the migration branch. The database export confirms every shop is on
    // Firebase Auth, so a reset email always has an account to land on.
    //
    // Firebase's Email Enumeration Protection still resolves this call even
    // when an address has no account, so the wording below stays conditional
    // on purpose: it must not become a way to test whether an email exists.
    await sendPasswordResetEmail(auth, email);

    // mask the email a little for privacy
    const [user, domain] = email.split('@');
    const masked = `${user.slice(0, 2)}***@${domain || ''}`;
    pendingAuthMessage = {
      page: '#login-page',
      type: 'success',
      text: `If an account exists for ${masked}, a password reset link has been sent. Check your inbox and spam folder.`
    };
    location.hash = "#/login";

  } catch (err) {
    console.error(err);
    if (err.code === "auth/user-not-found") {
      // Said "log in once with your current password first" when there was a
      // migration step to do. There isn't one any more, so that advice would
      // just send someone in a circle.
      showAuthMessage('#reset-page', "No account was found for this shop's registered email. Please contact support.", 'warn');
    } else if (err.code === "auth/invalid-email") {
      showAuthMessage('#reset-page', 'The email on record is invalid. Please contact support.');
    } else if (err.code === "auth/too-many-requests") {
      showAuthMessage('#reset-page', 'Too many attempts. Please wait a few minutes and try again.', 'warn');
    } else {
      showAuthMessage('#reset-page', 'Something went wrong: ' + err.message);
    }
  } finally {
    setBusy('#reset-btn', false);
  }
};


// Creating a shop. This used to lose data: the shop record was written with
// set(), which replaces the whole node, so signing up on a name that already
// existed replaced that shop's services, stock and staff with an empty
// skeleton. A client-side exists() check was added afterwards, but it ran
// AFTER the Auth account was created and check-then-write can be raced.
//
// Two changes below:
//   1. the name is checked BEFORE the Auth account exists, so a taken name no
//      longer strands the person with an account they cannot reuse - retrying
//      with a different shop name used to fail auth/email-already-in-use for
//      ever;
//   2. the write is a transaction that aborts when the node is already there,
//      so there is no ordering of events in which an existing shop is
//      overwritten. The server decides, not the client.
$('#signupForm').onsubmit = async (e) => {
  e.preventDefault();
  const userName = $('#signup_name').value.trim();
  const businessName = $('#signup_businessName').value.trim().toLowerCase();
  const businessEmail = $('#signup_businessEmail').value.trim();
  const businessPass = $('#signup_businessPassword').value.trim();

  if (!userName || !businessName || !businessEmail || !businessPass) {
    showAuthMessage('#signup-page', 'Fill in every field to create your shop.', 'warn');
    return;
  }

  setBusy('#signup', true);

  let createdUser = null;
  try {
    // 1) Is the name free? Asked first, so a taken name costs nothing.
    const existing = await get(child(shopRef, businessName));
    if (existing.exists()) {
      showAuthMessage('#signup-page', 'That business name is already taken. Please choose another.');
      return;
    }

    // 2) Create the Firebase Auth account.
    const userCredential = await createUserWithEmailAndPassword(auth, businessEmail, businessPass);
    createdUser = userCredential.user;

    // 3) Create the shop, and only create it. Returning undefined aborts the
    //    transaction, so a name claimed in the meantime is left untouched.
    const result = await runTransaction(child(shopRef, businessName), (current) => {
      if (current !== null) return;   // already exists - abort, change nothing
      return {
        shop: businessName,
        owner: {
          name: userName,
          email: businessEmail,
          uid: createdUser.uid,
          createdAt: Date.now()
        },
        lastServiceSn: 0,
        service: {},
        staff: {}
      };
    });

    if (!result.committed) {
      // Somebody claimed the name between step 1 and step 3. Their shop is
      // untouched. Remove the account we just made so this email stays usable.
      try { await deleteUser(createdUser); } catch (_) {}
      createdUser = null;
      showAuthMessage('#signup-page', 'That business name was just taken. Please choose another.');
      return;
    }

    localStorage.setItem('shopName', businessName);
    localStorage.setItem('author', userName);
    localStorage.setItem('role', 'Shop Owner');

    pendingAuthMessage = {
      page: '#login-page',
      type: 'success',
      text: 'Shop created. Sign in with your business name and password to continue.'
    };
    location.hash = "#/login";
  } catch (err) {
    console.error(err);
    // If the account was created but the shop was not, roll the account back
    // rather than leaving an email that can never be signed up again.
    if (createdUser) { try { await deleteUser(createdUser); } catch (_) {} }
    showAuthMessage('#signup-page', 'Could not create the shop: ' + err.message);
  } finally {
    setBusy('#signup', false);
  }
};


// Google sign-in removed. It derived the shop name from the email local part
// (saheer@gmail.com -> the shop named "saheer") and signed the person into that
// shop if it already existed, which is a straightforward takeover of any shop
// whose name matches somebody's email. The buttons were already hidden and
// disabled in auth/index.html, so nobody could reach it, but leaving the
// handler in place meant one stray class change would have switched it back on.
// Email + password login and the reset flow above cover everything it did.

